 ---

Digital SFX set by Kenney Vleugels (www.kenney.nl)

You may use these sounds in personal and commercial projects.
Credit (www.kenney.nl) would be nice but is not mandatory.

 --